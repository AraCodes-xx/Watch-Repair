<?php
require_once '../config/config.php';
require_login();

$user_id = get_current_user_id();
$booking_id = intval($_GET['id'] ?? 0);

// Fetch booking details
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT b.*, s.service_name, s.description, t.full_name as technician_name, t.contact_number as tech_contact, 
                        ts.start_time, ts.end_time, p.payment_proof, p.payment_method, p.verification_status, p.admin_remarks as payment_remarks,
                        wt.type_name as watch_type_name
                        FROM bookings b 
                        JOIN services s ON b.service_id = s.service_id 
                        LEFT JOIN technicians t ON b.technician_id = t.technician_id 
                        JOIN timeslots ts ON b.timeslot_id = ts.timeslot_id 
                        LEFT JOIN payments p ON b.booking_id = p.booking_id 
                        LEFT JOIN watch_types wt ON b.watch_type_id = wt.watch_type_id
                        WHERE b.booking_id = ? AND b.user_id = ?");
$stmt->bind_param("ii", $booking_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    redirect(SITE_URL . '/user/my_bookings.php');
}

$booking = $result->fetch_assoc();

// Fetch all services for this booking
$stmt = $conn->prepare("SELECT s.service_name, bs.service_price 
                        FROM booking_services bs 
                        JOIN services s ON bs.service_id = s.service_id 
                        WHERE bs.booking_id = ?");
$stmt->bind_param("i", $booking_id);
$stmt->execute();
$booking_services = $stmt->get_result();

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Details - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="navbar-container">
                <a href="../index.php" class="navbar-brand">⌚ <?php echo SITE_NAME; ?></a>
                <ul class="navbar-menu">
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="booking.php">Book Service</a></li>
                    <li><a href="my_bookings.php" class="active">My Bookings</a></li>
                    <li><a href="notifications.php">Notifications</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container" style="margin-top: 3rem; margin-bottom: 3rem;">
        <div class="d-flex justify-between align-center mb-3">
            <h1>📋 Booking Details</h1>
            <a href="my_bookings.php" class="btn btn-secondary">← Back to Bookings</a>
        </div>

        <div class="row">
            <div class="col-8">
                <div class="card mb-3">
                    <div class="card-header">Booking Information</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong>Services:</strong><br>
                            <?php if ($booking_services->num_rows > 0): ?>
                                <ul style="margin: 0.5rem 0; padding-left: 1.5rem;">
                                    <?php while ($service = $booking_services->fetch_assoc()): ?>
                                        <li><?php echo htmlspecialchars($service['service_name']); ?> - <?php echo format_currency($service['service_price']); ?></li>
                                    <?php endwhile; ?>
                                </ul>
                            <?php else: ?>
                                <?php echo htmlspecialchars($booking['service_name']); ?>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-3">
                            <strong>Status:</strong><br>
                            <span class="badge <?php echo get_status_badge_class($booking['status']); ?>">
                                <?php echo $booking['status']; ?>
                            </span>
                        </div>

                        <div class="row mb-3">
                            <div class="col-6">
                                <strong>Date:</strong><br>
                                <?php echo date('F d, Y', strtotime($booking['booking_date'])); ?>
                            </div>
                            <div class="col-6">
                                <strong>Time:</strong><br>
                                <?php echo date('g:i A', strtotime($booking['start_time'])); ?> - 
                                <?php echo date('g:i A', strtotime($booking['end_time'])); ?>
                            </div>
                        </div>

                        <?php if (!empty($booking['watch_type_name'])): ?>
                        <div class="mb-3">
                            <strong>Watch Type:</strong><br>
                            <?php echo htmlspecialchars($booking['watch_type_name']); ?>
                        </div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <strong>Problem Description:</strong><br>
                            <?php echo nl2br(htmlspecialchars($booking['problem_description'])); ?>
                        </div>

                        <div class="mb-3">
                            <strong>Service Address:</strong><br>
                            <?php echo nl2br(htmlspecialchars($booking['user_address'])); ?>
                        </div>

                        <?php if ($booking['technician_name']): ?>
                        <div class="row mb-3">
                            <div class="col-6">
                                <strong>Assigned Technician:</strong><br>
                                <?php echo htmlspecialchars($booking['technician_name']); ?>
                            </div>
                            <div class="col-6">
                                <strong>Contact:</strong><br>
                                <?php echo htmlspecialchars($booking['tech_contact']); ?>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($booking['admin_remarks']): ?>
                        <div class="alert alert-info">
                            <strong>Admin Remarks:</strong><br>
                            <?php echo nl2br(htmlspecialchars($booking['admin_remarks'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($booking['payment_proof']): ?>
                <div class="card">
                    <div class="card-header">Payment Proof</div>
                    <div class="card-body">
                        <img src="../uploads/<?php echo htmlspecialchars($booking['payment_proof']); ?>" 
                             alt="Payment Proof" 
                             style="max-width: 100%; border-radius: 0.5rem;">
                        
                        <?php if ($booking['payment_remarks']): ?>
                        <div class="alert alert-info mt-3">
                            <strong>Payment Verification Remarks:</strong><br>
                            <?php echo nl2br(htmlspecialchars($booking['payment_remarks'])); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-4">
                <div class="card mb-3">
                    <div class="card-header">Payment Summary</div>
                    <div class="card-body">
                        <?php if (!empty($booking['payment_method'])): ?>
                        <div class="mb-3">
                            <strong>Payment Method:</strong><br>
                            <?php echo htmlspecialchars($booking['payment_method']); ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="d-flex justify-between mb-2">
                            <span>Total Cost:</span>
                            <strong><?php echo format_currency($booking['total_cost']); ?></strong>
                        </div>
                        <div class="d-flex justify-between mb-2" style="color: var(--primary-color);">
                            <span>Down Payment (20%):</span>
                            <strong><?php echo format_currency($booking['down_payment']); ?></strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-between">
                            <span>Remaining Balance:</span>
                            <strong><?php echo format_currency($booking['total_cost'] - $booking['down_payment']); ?></strong>
                        </div>
                        
                        <?php if ($booking['verification_status']): ?>
                        <div class="mt-3">
                            <strong>Payment Status:</strong><br>
                            <span class="badge <?php echo get_status_badge_class($booking['verification_status']); ?>">
                                <?php echo $booking['verification_status']; ?>
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">Booking Timeline</div>
                    <div class="card-body">
                        <div style="font-size: 0.875rem;">
                            <div class="mb-2">
                                <strong>Created:</strong><br>
                                <?php echo date('M d, Y g:i A', strtotime($booking['created_at'])); ?>
                            </div>
                            <div class="mb-2">
                                <strong>Last Updated:</strong><br>
                                <?php echo date('M d, Y g:i A', strtotime($booking['updated_at'])); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if ($booking['status'] == 'Completed'): ?>
                <a href="add_feedback.php?booking_id=<?php echo $booking['booking_id']; ?>" class="btn btn-primary mt-3" style="width: 100%;">
                    ⭐ Rate This Service
                </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php closeDBConnection($conn); ?>
