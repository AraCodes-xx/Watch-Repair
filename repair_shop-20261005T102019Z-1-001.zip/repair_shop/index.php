<?php
require_once 'config/config.php';

// Fetch services
$conn = getDBConnection();
$services_query = "SELECT * FROM services WHERE is_active = 1 ORDER BY service_name";
$services_result = $conn->query($services_query);

// Fetch approved feedback
$feedback_query = "SELECT f.*, u.full_name, t.full_name as technician_name 
                   FROM feedback f 
                   JOIN users u ON f.user_id = u.user_id 
                   JOIN technicians t ON f.technician_id = t.technician_id 
                   WHERE f.is_approved = 1 
                   ORDER BY f.created_at DESC LIMIT 6";
$feedback_result = $conn->query($feedback_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Professional Watch Repair Services</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="navbar-container">
                <a href="index.php" class="navbar-brand">
                    ⌚ <?php echo SITE_NAME; ?>
                </a>
                <ul class="navbar-menu">
                    <li><a href="#home" class="active">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#reviews">Reviews</a></li>
                    <?php if (is_logged_in()): ?>
                        <li><a href="user/dashboard.php">Dashboard</a></li>
                        <li><a href="user/logout.php">Logout</a></li>
                    <?php elseif (is_admin_logged_in()): ?>
                        <li><a href="admin/dashboard.php">Admin Panel</a></li>
                        <li><a href="admin/logout.php">Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="btn btn-primary btn-sm">Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Professional Watch Repair & Servicing</h1>
                <p class="hero-subtitle">Fast • Reliable • Guaranteed</p>
                <div class="hero-features">
                    <span>✓ Expert Technicians</span>
                    <span>✓ 30-Day Warranty</span>
                    <span>✓ All Brands Serviced</span>
                </div>
                <div class="hero-cta">
                    <?php if (is_logged_in()): ?>
                        <a href="user/booking.php" class="btn btn-primary btn-lg">Book Now</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-lg">Book Now</a>
                    <?php endif; ?>
                    <a href="#how-it-works" class="btn btn-secondary btn-lg">How It Works</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Trust Indicators -->
    <section class="trust-indicators">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-number">10+</div>
                    <div class="stat-label">Years Experience</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">500+</div>
                    <div class="stat-label">Watches Repaired</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">5★</div>
                    <div class="stat-label">Customer Rating</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">24h</div>
                    <div class="stat-label">Avg Turnaround</div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section id="how-it-works" class="how-it-works p-5">
        <div class="container">
            <h2 class="text-center mb-4">How It Works</h2>
            <p class="text-center mb-5" style="color: var(--text-secondary);">Simple, transparent process from booking to completion</p>
            
            <div class="steps-grid">
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-icon">📋</div>
                    <h3>Select Service</h3>
                    <p>Choose from our range of professional watch repair services</p>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-icon">📅</div>
                    <h3>Book Appointment</h3>
                    <p>Pick your preferred date and time slot that works for you</p>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-icon">🔧</div>
                    <h3>Expert Repair</h3>
                    <p>Our certified technicians service your watch with care</p>
                </div>
                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-icon">✅</div>
                    <h3>Get Your Watch</h3>
                    <p>Pay remaining balance and collect your repaired watch</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Brands We Service -->
    <section class="brands-section p-5" style="background-color: var(--bg-darker);">
        <div class="container">
            <h2 class="text-center mb-4">Brands We Service</h2>
            <p class="text-center mb-5" style="color: var(--text-secondary);">We repair and service all major watch brands</p>
            
            <div class="brands-grid">
                <div class="brand-item">⌚ Rolex</div>
                <div class="brand-item">⌚ Seiko</div>
                <div class="brand-item">⌚ Casio</div>
                <div class="brand-item">⌚ Omega</div>
                <div class="brand-item">⌚ Citizen</div>
                <div class="brand-item">⌚ Tag Heuer</div>
                <div class="brand-item">⌚ Fossil</div>
                <div class="brand-item">⌚ Timex</div>
            </div>
            <p class="text-center" style="margin-top: 2rem; color: var(--text-secondary);">...and many more!</p>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="p-5">
        <div class="container">
            <h2 class="text-center mb-4">Our Services</h2>
            <p class="text-center mb-5" style="color: var(--text-secondary);">Comprehensive watch repair and maintenance with transparent pricing</p>
            
            <div class="services-grid">
                <?php while ($service = $services_result->fetch_assoc()): ?>
                <div class="service-card">
                    <div class="service-icon">🔧</div>
                    <h3><?php echo htmlspecialchars($service['service_name']); ?></h3>
                    <p><?php echo htmlspecialchars($service['description']); ?></p>
                    <div class="service-price"><?php echo format_currency($service['base_price']); ?></div>
                    <p style="font-size: 0.875rem; color: var(--text-secondary); margin-top: 0.5rem;">
                        Duration: ~<?php echo $service['duration_hours']; ?> hour(s)
                    </p>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Reviews Section -->
    <?php if ($feedback_result->num_rows > 0): ?>
    <section id="reviews" class="p-5" style="background-color: var(--bg-darker);">
        <div class="container">
            <h2 class="text-center mb-4">Customer Reviews</h2>
            <p class="text-center mb-5" style="color: var(--text-secondary);">See what our customers say about us</p>
            
            <div class="services-grid">
                <?php while ($review = $feedback_result->fetch_assoc()): ?>
                <div class="card">
                    <div class="d-flex justify-between align-center mb-2">
                        <strong><?php echo htmlspecialchars($review['full_name']); ?></strong>
                        <div>
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <span style="color: <?php echo $i <= $review['rating'] ? '#f59e0b' : '#334155'; ?>;">★</span>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p style="font-size: 0.875rem; color: var(--text-secondary); margin-bottom: 0.5rem;">
                        Technician: <?php echo htmlspecialchars($review['technician_name']); ?>
                    </p>
                    <p><?php echo htmlspecialchars($review['comment']); ?></p>
                    <p style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 1rem;">
                        <?php echo date('F d, Y', strtotime($review['created_at'])); ?>
                    </p>
                </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- Contact Section -->
    <section id="contact" class="p-5">
        <div class="container">
            <h2 class="text-center mb-4">Contact Us</h2>
            <div class="row" style="margin-top: 3rem;">
                <div class="col-4">
                    <div class="card text-center">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">📍</div>
                        <h4>Location</h4>
                        <p>123 Watch Street, Manila, Philippines</p>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card text-center">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">📞</div>
                        <h4>Phone</h4>
                        <p>+63 917 123 4567</p>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card text-center">
                        <div style="font-size: 2rem; margin-bottom: 1rem;">✉️</div>
                        <h4>Email</h4>
                        <p><?php echo ADMIN_EMAIL; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div>
                    <h4>⌚ <?php echo SITE_NAME; ?></h4>
                    <p>Professional watch repair and maintenance services you can trust.</p>
                </div>
                <div>
                    <h4>Quick Links</h4>
                    <p><a href="#services">Services</a></p>
                    <p><a href="#reviews">Reviews</a></p>
                    <p><a href="user/login.php">Login</a></p>
                </div>
                <div>
                    <h4>Business Hours</h4>
                    <p>Monday - Saturday: 8:00 AM - 6:00 PM</p>
                    <p>Sunday: Closed</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Smooth scrolling
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    </script>
</body>
</html>
<?php closeDBConnection($conn); ?>
