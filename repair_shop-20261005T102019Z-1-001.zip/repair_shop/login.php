<?php
require_once 'config/config.php';

$error = '';

// Redirect if already logged in
if (is_logged_in()) {
    redirect(SITE_URL . '/user/dashboard.php');
}

if (is_admin_logged_in()) {
    redirect(SITE_URL . '/admin/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email_or_username = sanitize_input($_POST['login']);
    $password = $_POST['password'];
    
    if (empty($email_or_username) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        $conn = getDBConnection();
        
        // First, try to login as admin
        $stmt = $conn->prepare("SELECT admin_id, username, password, full_name FROM admin WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $email_or_username, $email_or_username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $admin = $result->fetch_assoc();
            
            if (password_verify($password, $admin['password'])) {
                $_SESSION['admin_id'] = $admin['admin_id'];
                $_SESSION['admin_name'] = $admin['full_name'];
                $_SESSION['admin_username'] = $admin['username'];
                
                redirect(SITE_URL . '/admin/dashboard.php');
            } else {
                $error = 'Invalid credentials';
            }
        } else {
            // Try to login as regular user
            $stmt = $conn->prepare("SELECT user_id, full_name, email, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email_or_username);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $user = $result->fetch_assoc();
                
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['user_name'] = $user['full_name'];
                    $_SESSION['user_email'] = $user['email'];
                    
                    redirect(SITE_URL . '/user/dashboard.php');
                } else {
                    $error = 'Invalid credentials';
                }
            } else {
                $error = 'Invalid credentials';
            }
        }
        
        $stmt->close();
        closeDBConnection($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container" style="max-width: 500px; margin-top: 5rem;">
        <div class="card">
            <div class="card-header text-center">
                <h2>Welcome Back</h2>
                <p>Login to your account</p>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (isset($_GET['registered'])): ?>
                    <div class="alert alert-success">Registration successful! Please login.</div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label class="form-label">Email or Username</label>
                        <input type="text" name="login" class="form-control" placeholder="Enter your email or username" required autofocus>
                        <small style="color: var(--text-secondary);">Use email for customer login, username for admin login</small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Login</button>
                </form>
            </div>
            <div class="card-footer text-center">
                <p>Don't have an account? <a href="user/signup.php">Sign up here</a></p>
                <p><a href="index.php">← Back to Home</a></p>
            </div>
        </div>
        
        <div class="card mt-3" style="background-color: var(--bg-darker); border: 1px solid var(--border-color);">
            <div class="card-body">
                <small style="color: var(--text-secondary);">
                    <strong>Demo Credentials:</strong><br>
                    Admin: <code>admin</code> / <code>password</code><br>
                    Customer: Create new account or use your registered email
                </small>
            </div>
        </div>
    </div>
</body>
</html>
