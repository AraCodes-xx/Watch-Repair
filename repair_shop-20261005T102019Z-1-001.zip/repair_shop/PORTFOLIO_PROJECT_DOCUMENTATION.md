# Portfolio Project Documentation

## Documentation Scope

This document describes the current project based on static inspection of the source files, SQL files, configuration, assets, and existing project documentation. It does not represent a live runtime test, penetration test, or verification of the currently configured database.

Sensitive values from configuration files, payment-account settings, uploaded payment proofs, and database credentials are intentionally omitted.

## 1. Project Identification

### Project Name

The project uses more than one name in its files:

- Watch Repair Shop Website
- Watch Repair Shop Booking and Management System
- MC Repair / MC Repair Shop

For portfolio use, **MC Repair - Watch Repair Booking and Management System** is an accurate combined name, subject to the developer's preferred branding.

### Project Type

A server-rendered PHP/MySQL web application for watch-repair service booking and shop administration.

### Project Status

The project contains substantial implemented functionality for an educational or academic-style prototype. Existing documentation describes it as complete and production-ready, but current source inspection found unresolved schema, workflow, and security inconsistencies. Therefore, production readiness cannot be verified from the repository alone.

### Year / Version

Historical documentation identifies a revised version 2.0 dated October 22, 2025, with later enhancement notes referring to versions 2.1, 2.2, and 2.4. An authoritative current version or project creation year is **not determinable from the current project files**.

### Primary Purpose

The system allows customers to request watch-repair services by selecting services, describing a problem, choosing an appointment date and time slot, submitting payment proof, and tracking the repair process. It also provides administrators with tools to review bookings and payments, assign technicians, manage shop data, and moderate customer feedback.

### Problem the System Addresses

The system addresses the need to organize watch-repair appointments, customer information, payment-proof verification, technician assignment, repair status tracking, and customer feedback in one web-based system instead of handling these activities through disconnected manual processes.

### Intended Users

- Public visitors who browse services and may track a booking using booking information.
- Customers who register, book services, submit payment proof, track progress, receive notifications, and rate completed services.
- Administrators who manage bookings, payments, services, technicians, users, time slots, watch types, and feedback.
- Technicians are represented as operational records assigned to bookings. No technician login or technician-facing portal was found.

### My Likely Development Role

**Not determinable from the current project files.** The source identifies the application and its implementation, but it does not reliably identify the individual developer's ownership or contribution boundaries.

## 2. Technology Stack

### Frontend

- HTML5 markup embedded in PHP templates.
- CSS3.
- Vanilla JavaScript.
- Responsive layouts implemented with custom CSS grid and flexbox rules.
- Native browser form controls and file inputs.

No React, Vue, Angular, Vite, Tailwind CSS, Bootstrap, or other frontend framework was found.

### Backend

- PHP, documented as PHP 7.4 or later.
- Server-rendered PHP pages and form handlers.
- PHP sessions for login state.
- `mysqli` for MySQL database access.
- PHP file-upload handling for payment proof images.

### Database

- MySQL-compatible relational database.
- Foreign keys, enumerated status values, unique constraints, check constraints, timestamps, and cascading or nullifying deletes.
- The main configuration targets one database name, while one complete SQL dump targets a different database name. This discrepancy is documented later in this file.

### Authentication

- Separate customer and administrator account tables.
- Customer login through email.
- Administrator login through username or email.
- Password hashing with PHP's `password_hash()`.
- Password verification with `password_verify()`.
- Session flags for customer and administrator access.

### APIs / Services

- Internal PHP JSON availability endpoint: `api/get_timeslot_availability.php`.
- A second internal availability endpoint exists at `user/check_slot_availability.php`.
- AJAX/fetch requests are used to refresh time-slot availability.
- Database-backed notifications are used inside the application.
- No external email, SMS, push notification, payment gateway, or third-party API integration was verified.

### Frameworks

No application framework was found. The project uses procedural PHP pages and shared configuration/helper functions.

### Libraries

No external runtime libraries were verified. The project primarily uses PHP built-ins, `mysqli`, browser JavaScript APIs, and custom CSS.

### Development Tools

- XAMPP.
- Apache.
- MySQL.
- phpMyAdmin is referenced by the installation documentation.
- Apache `.htaccess` configuration.
- Browser developer-console logging is used by some debugging and availability code.

No `package.json`, Composer manifest, build configuration, or dependency directory was found in the current project files.

### Other Technologies

- Apache URL/server configuration through `.htaccess`.
- Local filesystem storage under `uploads/` for payment-proof images.
- JSON responses for availability data.

## 3. System Users and Roles

### Public Visitor

**Purpose:** Browse the shop website and available services without signing in.

**Access:** Homepage, service information, approved reviews, contact information, login, registration, and public booking tracking.

**Main Features:**

- View active services and prices.
- View approved customer reviews.
- View business information and service process.
- Open the login or registration flow.
- Track a booking by providing booking information and customer email.

**Restrictions:** Cannot create a booking or access customer booking history without an authenticated customer session.

**Important Workflow:** Public visitor -> login or registration -> customer portal.

### Customer

**Purpose:** Request and monitor watch-repair services.

**Access:** Customer dashboard and customer pages protected by `require_login()`.

**Main Features:**

- Register an account.
- Log in and log out.
- Update profile details.
- Change password.
- Select watch type and one or more services.
- Describe the watch problem.
- Select a future appointment date and time slot.
- Confirm a service address.
- Select a payment method.
- Upload payment proof.
- View booking history and details.
- View payment status and remaining balance.
- View technician assignment.
- View status timelines.
- Receive database-backed notifications.
- Mark notifications as read.
- Rate a completed service from one to five stars.
- Submit a comment about the completed service.

**Restrictions:** Customer queries generally filter records by the authenticated customer ID. Feedback is limited to completed bookings with an assigned technician, and the source checks for an existing feedback record before accepting another one.

**Important Workflow:** Customer registration/login -> booking submission -> payment review -> technician assignment -> service completion -> feedback.

### Administrator

**Purpose:** Operate and administer the watch-repair booking system.

**Access:** Administrative pages protected by `require_admin()`.

**Main Features:**

- View dashboard metrics.
- View and filter bookings.
- Inspect booking details.
- Verify or reject payment proof.
- Add payment rejection remarks.
- Approve, reject, complete, or cancel bookings through available administrative flows.
- Assign technicians.
- Track technician job history.
- Update remaining payment status.
- Manage services.
- Manage watch types.
- Manage technicians.
- Manage customers/users.
- Manage time slots.
- Review, approve, and delete feedback.
- Sign out through the administrator logout flow.

**Restrictions:** Administrative pages require the administrator session flag. There is no evidence of multiple administrator permission levels or a separate fine-grained role/permission system.

**Important Workflow:** Administrator login -> review booking/payment -> approve or reject -> assign technician -> update service status -> update final payment status.

### Technician

**Purpose:** Represent the person assigned to perform a repair.

**Access:** Technician data is viewed and managed by administrators. No technician authentication, login, dashboard, or direct workflow was found.

**Main Features:**

- Name, contact, email, specialization, availability, rating, and job count are stored.
- Administrators can assign a technician to a booking.
- Administrators can view technician job history.

**Restrictions:** Technicians cannot directly access the application as a documented user role because no technician portal was found.

## 4. System Modules

### Public Website

**Purpose:** Present the repair shop and direct visitors into the booking or authentication flows.

**Primary Users:** Public visitors and customers.

**Main Functions:**

- Hero section and call-to-action.
- Active service listing with prices and approximate durations.
- Approved customer reviews.
- Contact information and business hours.
- Service process explanation.
- Login and dashboard navigation based on session state.

**Related Pages/Components:** `index.php`, shared stylesheet, navigation, service cards, review cards, contact section, footer.

**Important Notes:** The homepage's authenticated “Book Now” link points to the older `user/booking.php` implementation, while the customer dashboard's primary booking link points to `user/booking_wizard.php`.

### Authentication and Account Management

**Purpose:** Register customers and establish separate customer or administrator sessions.

**Primary Users:** Customers and administrators.

**Main Functions:**

- Unified login page.
- Customer signup.
- Password hashing and verification.
- Session-based redirects.
- Customer profile updates.
- Customer password changes.
- Customer and administrator logout.

**Related Pages/Components:** `login.php`, `user/signup.php`, `user/profile.php`, `user/logout.php`, `admin/logout.php`, `config/config.php`.

**Important Notes:** `admin/login.php` and `user/login.php` redirect to the unified login flow.

### Customer Dashboard

**Purpose:** Give customers a summary of their account and current service activity.

**Primary Users:** Customers.

**Main Functions:**

- Total booking count.
- Pending booking count.
- Completed-booking spending total.
- Recent bookings list.
- Unread notification count.
- Quick links to booking, bookings, notifications, and profile.
- Active service listing and approved reviews.

**Related Pages/Components:** `user/dashboard.php`, shared navigation, cards, tables, notification badge.

### Booking and Scheduling

**Purpose:** Collect repair requirements and schedule an appointment.

**Primary Users:** Customers; administrators review the result.

**Main Functions:**

- Watch-type selection.
- Multiple-service selection.
- Problem description.
- Service address.
- Date selection.
- Sunday exclusion.
- Past-date exclusion.
- Time-slot selection.
- Technician-based capacity display.
- Payment method selection.
- Payment-proof upload.
- Booking status initialization.

**Related Pages/Components:** `user/booking.php`, `user/booking_wizard.php`, `user/process_booking_wizard.php`, `api/get_timeslot_availability.php`, `user/check_slot_availability.php`.

**Important Notes:** Two booking implementations remain in the repository. They do not use identical payment methods, payment percentages, notification behavior, or database handling.

### Payment Proof and Verification

**Purpose:** Record an initial payment and allow an administrator to review the submitted proof.

**Primary Users:** Customers and administrators.

**Main Functions:**

- Select a payment method.
- Display configured payment-account instructions.
- Upload a payment-proof image.
- Store payment amount, method, proof filename, verification status, remarks, verifier, and verification timestamp.
- Approve or reject payment proof through administrative screens.
- Record rejection remarks.
- Track remaining balance and final payment state where the schema supports it.

**Related Pages/Components:** `config/payment_accounts.php`, `config/config.php`, `admin/view_payment.php`, `admin/edit_payment.php`, `admin/booking_detail.php`, `uploads/`.

**Important Notes:** Payment-account configuration exists, but its values are intentionally not reproduced here. Payment verification uses inconsistent status vocabulary in different source files.

### Booking Operations and Technician Assignment

**Purpose:** Move a submitted booking through administrative review and service completion.

**Primary Users:** Administrators, with status information visible to customers.

**Main Functions:**

- Filter bookings by status.
- Inspect customer, service, date, address, problem, payment, and watch-type details.
- Approve or reject based on payment review.
- Assign technicians.
- Mark bookings completed or cancelled.
- Add administrative remarks.
- Update final payment status.
- Send database notifications for selected status changes.
- View technician job history.

**Related Pages/Components:** `admin/view_booking.php`, `admin/booking_detail.php`, `admin/edit_booking.php`, `admin/technician_history.php`.

### Administration and CRUD

**Purpose:** Maintain the data needed to operate the shop.

**Primary Users:** Administrators.

**Main Functions:**

- Create, view, edit, activate/deactivate, and delete services.
- Create, view, edit, activate/deactivate, and delete watch types.
- Create, view, edit, activate/deactivate, and delete technicians.
- View and update customer records.
- Create, view, edit, activate/deactivate, and delete time slots.
- Use a shared entity configuration to drive generic management forms.

**Related Pages/Components:** `admin/manage.php`, `admin/form.php`, `admin/delete.php`, `admin/config/entities.php`.

**Important Notes:** The generic CRUD system uses an allow-list of configured entities and fields, but destructive operations are initiated through GET links.

### Feedback and Review Moderation

**Purpose:** Collect customer ratings and control which reviews appear publicly.

**Primary Users:** Customers and administrators.

**Main Functions:**

- Submit one-to-five-star feedback after completion.
- Add a written comment.
- Update technician rating and total job count when feedback is submitted.
- Filter feedback by pending or approved state.
- Approve feedback for homepage display.
- Delete feedback.

**Related Pages/Components:** `user/add_feedback.php`, `admin/view_feedback.php`, `admin/edit_feedback.php`, `admin/delete_feedback.php`, `index.php`.

### Notifications

**Purpose:** Provide in-application updates related to bookings and payments.

**Primary Users:** Customers; notification records are created by customer and administrator workflows.

**Main Functions:**

- Create notification records in the database.
- Show unread count on customer navigation.
- List notifications by customer.
- Link a notification to a booking.
- Mark one notification as read.
- Mark all notifications as read.

**Related Pages/Components:** `config/config.php`, `user/notifications.php`, customer dashboard, booking and payment handlers.

**Important Notes:** The source demonstrates database notifications, not email, SMS, push, WebSocket, or other realtime delivery.

## 5. Complete Feature Inventory

### Public Website

- Homepage with branded navigation.
- Hero section with booking call-to-action.
- Active services loaded from the database.
- Service prices and approximate duration display.
- Approved customer review display.
- Contact information section.
- Business-hours section.
- “How It Works” process section.
- Brand/service marketing content.
- Session-aware navigation for public, customer, and administrator states.
- Public booking lookup form.

### Customer Authentication and Accounts

- Customer registration.
- Required full name, email, contact number, address, password, and confirmation fields.
- Email-format validation.
- Minimum password-length validation.
- Password confirmation validation.
- Duplicate-email check.
- Password hashing.
- Customer login by email.
- Session-backed customer access.
- Logout and session destruction.
- Profile name update.
- Profile contact-number update.
- Profile address update.
- Read-only email display in profile.
- Current-password verification before password change.
- New-password length and confirmation validation.

### Customer Dashboard

- Total bookings statistic.
- Pending bookings statistic.
- Completed-booking spending statistic.
- Recent bookings table.
- Unread notification count.
- Quick action buttons.
- Active services list.
- Approved reviews list.

### Booking Creation

- Booking through the legacy form at `user/booking.php`.
- Booking through the five-step wizard at `user/booking_wizard.php`.
- Watch-type selection.
- Multiple service selection.
- Service description and price display.
- Problem description capture.
- Service address capture.
- Address prefilled from the customer's profile in the wizard.
- Future-date selection.
- Sunday restriction.
- Same-day expired-slot restriction in client-side availability logic.
- Time-slot selection.
- Available-technician count used as a slot-capacity value.
- Dynamic availability refresh through fetch/AJAX.
- Availability labels showing current bookings, maximum slots, and available spots.
- Payment-method selection.
- Payment-account instruction display in the wizard.
- Payment-proof image upload.
- Client-side required-field validation.
- Server-side date, service, and file checks.
- Booking creation with pending status.
- Payment record creation.
- Junction records for selected services in the legacy booking flow.

### Booking History and Tracking

- Customer booking history.
- Booking status badges.
- Payment verification status display.
- Payment method display.
- Down-payment display.
- Remaining-balance display.
- Assigned-technician display.
- Booking detail view.
- Problem description and service-address display.
- Watch-type display.
- Selected-service detail display when junction records exist.
- Payment-proof display for the customer.
- Administrator remarks display.
- Booking creation and last-updated timestamps.
- Customer status timeline.
- Public tracking by booking identifier and email.
- Public progress tracker showing payment, approval, technician assignment, and completion stages.

### Payments

- Payment method selection.
- Configurable payment-account information.
- Payment-proof file upload.
- File size limit configuration.
- Extension allowlist for uploaded image files.
- Payment amount storage.
- Payment method storage.
- Verification status storage.
- Administrator remarks.
- Verifying administrator reference.
- Verification timestamp.
- Payment filtering by status in the admin area.
- Payment proof preview in administrator screens.
- Payment rejection workflow.
- Remaining-balance tracking where the `payment_status` column exists.
- Fully-paid state where supported by the selected schema.

### Administrator Dashboard

- Total booking count.
- Pending booking count.
- Approved booking count.
- Completed booking count.
- Completed-booking income total.
- Down-payment total.
- Pending payment-verification count.
- Technician count.
- Registered-user count.
- Recent bookings table.
- Quick links for pending bookings, payment review, service creation, and technician creation.
- Fixed sidebar navigation.
- Mobile sidebar toggle.

### Booking Administration

- All-bookings list.
- Status filters for all, pending, approved, completed, and rejected states.
- Customer contact information display.
- Service, appointment, technician, amount, and status display.
- Booking detail workflow.
- Payment verification from booking detail.
- Payment rejection with remarks.
- Booking approval after payment verification in the newer booking-detail flow.
- Technician assignment.
- Booking status update.
- Booking cancellation.
- Service completion.
- Administrative remarks.
- Customer notification creation for selected actions.
- Booking deletion.

### Administrative CRUD

- Service creation and editing.
- Service description and price management.
- Service duration management.
- Service activation/deactivation.
- Technician creation and editing.
- Technician contact and specialization management.
- Technician availability management.
- Technician rating and job-count display.
- Technician history view.
- Customer/user record view and update.
- Time-slot creation and editing.
- Time-slot start/end validation.
- Time-slot activation/deactivation.
- Watch-type creation and editing.
- Watch-type description management.
- Watch-type activation/deactivation.
- Generic form rendering from `admin/config/entities.php`.
- Generic entity allow-list validation.

### Feedback and Notifications

- Completed-booking eligibility check for feedback.
- Assigned-technician requirement for feedback.
- One-feedback check in application logic.
- One-to-five-star rating.
- Interactive star selector.
- Rating labels from Poor to Excellent.
- Required feedback comment.
- Technician rating update.
- Feedback approval flag.
- Feedback moderation filters.
- Feedback deletion.
- Homepage display of approved feedback.
- Booking-submission notification in the legacy booking path.
- Payment verification notifications in administrator flows.
- Booking status notifications for selected statuses.
- Technician-assignment notification in the legacy administrative edit flow.
- Payment-completion notification.
- Notification list and unread highlighting.
- Mark-one-read and mark-all-read actions.

## 6. Important Workflows

### Customer Registration and Login

1. A visitor opens the unified login page.
2. A new customer follows the signup link.
3. The customer submits name, email, contact number, address, password, and confirmation.
4. The server validates the email, password length, confirmation, and duplicate email condition.
5. The password is hashed before insertion into the `users` table.
6. The customer is redirected to login.
7. On successful login, a customer session is created and the customer is redirected to the dashboard.

### Customer Booking Through the Five-Step Wizard

1. The authenticated customer opens `user/booking_wizard.php`.
2. The customer selects a watch type.
3. The customer describes the problem and selects one or more services.
4. The customer selects a future date and time slot.
5. The browser excludes Sundays and refreshes slot availability through the internal JSON endpoint.
6. The customer confirms or edits the service address.
7. The customer reviews the booking summary.
8. The customer selects a configured payment method.
9. The customer uploads payment proof.
10. `process_booking_wizard.php` validates the date, Sunday restriction, selected services, capacity, and upload presence.
11. The application calculates the total and down payment.
12. A booking and payment record are intended to be created inside a database transaction.
13. The customer is redirected to the booking list with a success message.

**Implementation note:** The wizard processor currently inserts into `booking_services` without supplying the schema's required `service_price` value. This means the workflow is implemented in source but may fail against the current schema without database or code alignment.

### Customer Booking Through the Legacy Form

1. The authenticated customer opens `user/booking.php`.
2. The customer selects multiple services.
3. The customer selects a date using the custom calendar.
4. The browser disables past dates and Sundays.
5. The customer selects a time slot and the page refreshes availability through the internal API.
6. The customer selects a watch type, describes the problem, and confirms the address.
7. The customer selects a payment method and uploads payment proof.
8. The server calculates the total and down payment.
9. The server inserts the booking, selected service junction rows, payment record, and initial notification.
10. The customer is redirected to the booking list.

**Implementation note:** The homepage links authenticated users to this legacy form, while the dashboard links to the newer wizard. The two paths contain inconsistent payment percentages and payment-method handling.

### Payment Review and Booking Approval

1. A customer submits a booking with payment proof.
2. The booking begins with a pending booking status and pending payment verification state.
3. An administrator opens the payment or booking-detail screen.
4. The administrator views the payment amount, method, and uploaded proof image.
5. The administrator either verifies or rejects the payment.
6. A rejection may include remarks explaining the decision.
7. Selected administrative handlers create a notification for the customer.
8. In the newer booking-detail flow, verification also changes the booking status to approved.

**Implementation note:** Some source files use `Verified` as the accepted payment status, while other source files and `schema.sql` use `Approved`. The exact runtime behavior depends on the selected database schema and active administrative path.

### Technician Assignment and Service Completion

1. An administrator opens an approved booking.
2. The administrator selects a technician from the technician records.
3. The booking stores the technician reference.
4. The customer can see the assigned technician in booking details and tracking views.
5. The administrator marks the booking completed or cancelled through the available status controls.
6. A selected status change creates a customer notification.
7. A completed customer booking becomes eligible for feedback.

### Remaining Balance and Final Payment

1. The system displays the total cost and calculated down payment.
2. An approved or completed booking displays a remaining balance.
3. The customer is instructed to pay the remaining balance to the technician upon service completion.
4. An administrator can update the booking payment state to a fully-paid value where the selected schema includes `payment_status`.
5. A payment-completion notification may be created.

### Feedback Submission and Moderation

1. A customer opens the feedback page for a completed booking.
2. The server verifies that the booking belongs to the customer, is completed, and has an assigned technician.
3. The application checks whether feedback already exists for the booking.
4. The customer selects a one-to-five-star rating and enters a comment.
5. The feedback is stored as pending approval.
6. The technician's average rating and job count are updated by the application.
7. An administrator reviews the feedback.
8. Approved feedback becomes eligible for display on the public homepage.

### Notification Handling

1. Booking, payment, assignment, or status handlers call the shared notification helper for supported events.
2. A notification row is stored with the customer, optional booking, title, message, read state, and timestamp.
3. The customer dashboard counts unread notifications.
4. The customer opens the notification page.
5. The customer can open the related booking, mark one notification as read, or mark all notifications as read.

## 7. Database

### Database Technology

The application targets MySQL or a compatible MySQL database and connects through PHP's `mysqli` extension. The connection helper sets the character set to `utf8mb4`.

### Primary Tables / Entities

The SQL files define the following entities:

- `admin`: Administrator accounts.
- `users`: Customer accounts and profile information.
- `services`: Repair services, descriptions, prices, durations, and active state.
- `watch_types`: Watch categories selectable during booking.
- `technicians`: Technician contact, specialization, availability, rating, and job count.
- `timeslots`: Appointment start and end times and active state.
- `bookings`: Customer appointments, selected primary service, date, slot, watch type, problem, address, pricing, status, and administrative remarks.
- `booking_services`: Junction table for multiple selected services and captured service prices.
- `payments`: Payment amount, proof filename, method, verification state, remarks, verifier, and verification timestamp.
- `feedback`: Customer rating/comment records associated with a completed booking and technician.
- `notifications`: Customer notification records and read state.

### Important Relationships

- `bookings.user_id` references `users.user_id`.
- `bookings.service_id` references `services.service_id`.
- `bookings.technician_id` references `technicians.technician_id` and is set to null when the technician is deleted.
- `bookings.timeslot_id` references `timeslots.timeslot_id`.
- `bookings.watch_type_id` references `watch_types.watch_type_id` and is set to null when the watch type is deleted.
- `booking_services.booking_id` references `bookings.booking_id`.
- `booking_services.service_id` references `services.service_id`.
- `payments.booking_id` references `bookings.booking_id`.
- `payments.verified_by` references `admin.admin_id` and is set to null when the administrator is deleted.
- `feedback.booking_id` references `bookings.booking_id`.
- `feedback.user_id` references `users.user_id`.
- `feedback.technician_id` references `technicians.technician_id`.
- `notifications.user_id` references `users.user_id`.
- `notifications.booking_id` references `bookings.booking_id`.

### Important Status Fields

- `bookings.status`: `Pending`, `Approved`, `Rejected`, `Completed`, or `Cancelled` in the primary schema definitions.
- `bookings.payment_status`: `Down Payment Only` or `Fully Paid` in the complete schema and payment-status migration, but absent from the older `schema.sql`.
- `payments.verification_status`: `Pending`, `Approved`, or `Rejected` in `schema.sql`; `COMPLETE_DATABASE.sql` uses `Verified` instead of `Approved`.
- `services.is_active`: Controls service availability.
- `watch_types.is_active`: Controls watch-type availability.
- `technicians.is_available`: Used in technician capacity calculations.
- `timeslots.is_active`: Controls available time slots.
- `feedback.is_approved`: Controls public review display.
- `notifications.is_read`: Controls unread notification state.

### Database Security and Integrity Mechanisms

The SQL definitions provide:

- Primary keys and auto-increment identifiers.
- Unique usernames and email addresses where defined.
- Required fields using `NOT NULL`.
- Foreign-key referential integrity.
- Cascade or set-null delete behavior.
- Enumerated booking and payment states.
- A one-to-five rating check constraint.
- Automatic creation and update timestamps.

No database-level row ownership policy, database authorization policy, trigger, stored procedure, stored function, view, or explicit database grant configuration was found.

### Important Schema and Source Conflicts

- `config/database.php` targets `watch_repair_shop`.
- `database/schema.sql` also targets `watch_repair_shop`.
- `database/COMPLETE_DATABASE.sql` targets `repair_shop` instead.
- `schema.sql` does not define `bookings.payment_status`, although current PHP pages query and update that column.
- `schema.sql` uses `Approved` for payment verification, while the complete schema and some current PHP use `Verified`.
- `booking_services.service_price` is required by the schema, but `process_booking_wizard.php` inserts only the booking and service IDs.
- `add_watch_type.sql` adds an older `watch_type` text column, while current application code uses `watch_type_id` and the normalized `watch_types` table.
- `migrate_booking_improvements.sql` references the older `bookings.watch_type` column during data migration, even though a clean current schema may not contain it.
- Multiple payment rows are permitted for a booking because no unique constraint on `payments.booking_id` was found.
- Booking capacity is checked before insertion, but no database-level uniqueness or locking mechanism prevents concurrent submissions from exceeding capacity.

### Live Database Verification

No live database connection or data inspection was performed. The number of records, active users, actual configured schema, and current production data are **not determinable from the current project files**.

## 8. Supabase

Supabase is not used by the current project files.

- Supabase Authentication: Not found.
- Supabase database: Not found.
- Supabase Storage: Not found.
- Supabase Row Level Security: Not found.
- Supabase policies: Not found.
- Supabase functions: Not found.
- Supabase triggers: Not found.
- Supabase Realtime: Not found.
- Other Supabase services: Not found.

The project instead uses PHP sessions, MySQL, and local filesystem uploads.

## 9. Security and Access Control

### Identifiable Implemented Controls

- Customer pages use `require_login()`.
- Administrator pages use `require_admin()`.
- Customer and administrator sessions use separate session keys.
- Passwords are hashed with PHP's `password_hash()`.
- Passwords are checked with `password_verify()`.
- Most user-controlled SQL values are handled with prepared statements.
- Customer booking and notification queries generally include the authenticated customer ID.
- Customer booking details check both booking ID and current customer ID.
- Output is frequently escaped with `htmlspecialchars()`.
- Form inputs use basic required-field validation.
- Email values use `FILTER_VALIDATE_EMAIL` in registration and generic admin forms.
- Service and time-slot values are converted or validated in several booking paths.
- Upload size is limited through application configuration and Apache settings.
- Upload extensions are restricted to configured image extensions.
- Apache directory browsing is disabled.
- Apache response headers include same-origin framing, MIME-sniffing protection, and a legacy XSS header.
- Session cookies are configured as HTTP-only through `.htaccess`.
- Strict session mode is enabled through `.htaccess`.
- Generic administrative CRUD uses a configured entity allow-list rather than accepting arbitrary table names directly from the request.

### Security Limitations Visible From Static Inspection

These observations are documentation findings, not penetration-test results:

- No CSRF-token implementation was found in the reviewed forms.
- Several state-changing operations use GET requests, including deletion and notification read actions.
- Login code does not visibly call `session_regenerate_id()` after successful authentication.
- Upload validation checks filename extension and size but does not visibly validate MIME type or file content.
- Uploaded payment proofs are served directly from a public `uploads` path.
- `.htaccess` enables `display_errors`, which is not appropriate for a production deployment.
- Diagnostic and test pages are present in the web root and can expose session, user, database, schema, or error information if publicly accessible.
- `view_errors.php` attempts to display Apache error-log contents.
- `fix_user_issue.php` contains a test-user creation path.
- The availability API is not protected by customer authentication and may include database exception text in its JSON response.
- Some dynamic query construction uses escaped strings rather than prepared statements.
- State-changing administrative operations do not consistently validate allowed status values server-side before update.
- No rate limiting, multi-factor authentication, password-reset flow, audit log, or fine-grained administrator permissions were found.

## 10. UI/UX

### Overall Design Approach

The interface uses a custom dark minimalist visual style:

- Dark navy and near-black backgrounds.
- Indigo and purple gradient accents.
- Card-based content sections.
- Color-coded status badges.
- Green, yellow, red, and blue feedback states.
- Rounded cards, buttons, panels, and form controls.
- Hover transitions and elevation effects.
- Emoji and icon-like symbols for actions and workflow stages.

### Navigation

- Public pages use a sticky horizontal navigation bar.
- Customer pages use a shared horizontal navigation bar with dashboard, booking, bookings, notifications, profile, and logout links.
- Administrator pages primarily use a fixed vertical sidebar.
- The administrator sidebar collapses off-screen on small displays and can be opened with a toggle button.

### Dashboard

- Customer dashboard uses statistic cards, quick actions, recent-booking tables, service cards, and review cards.
- Administrator dashboard uses multiple metric-card rows, quick actions, and a recent-bookings table.
- Database queries supply the dashboard counts and totals.

### Forms

- Registration, login, profile, password, booking, payment, CRUD, feedback, and moderation forms are implemented with styled custom controls.
- The newer booking flow uses a five-step progress interface.
- The legacy booking flow uses a custom calendar and a multi-column form layout.
- The payment flow uses file inputs and dynamically displayed payment instructions.

### Tables and Cards

- Administrative records are presented in tables.
- Customer bookings use detailed booking cards with status timelines and payment panels.
- Services, reviews, dashboard metrics, and workflow summaries use cards.
- Tables are styled for responsive overflow behavior through the shared stylesheet, although actual mobile readability should be verified at runtime.

### Modals and Interactive Components

- Payment rejection modal.
- Payment-proof enlargement modal.
- Logout confirmation modal.
- Dynamic booking wizard navigation.
- Interactive star rating.
- Dynamic payment-account display.
- Date and time-slot availability refresh.
- Administrator sidebar toggle.

### Responsive Behavior

The CSS includes a mobile breakpoint around 768px. At smaller widths, columns become full-width, grids collapse, the administrator sidebar becomes hidden until toggled, and some navigation/action layouts become vertical. Mobile behavior is implemented in CSS and inline JavaScript rather than through a frontend framework.

### Dark / Light Mode

Only the dark visual theme is implemented. No user-controlled dark/light mode toggle was found.

## 11. Technical Highlights

### Technician-Based Time-Slot Capacity

The application counts technicians marked available and uses that count as the maximum number of bookings per time slot. The browser requests availability by date and displays current bookings, maximum capacity, and remaining spots. This is technically meaningful because it connects scheduling capacity to operational resource availability rather than using only a fixed hard-coded slot limit.

The implementation is currently a pre-insertion check and does not include a database-level concurrency lock or capacity constraint.

### Multi-Service Bookings

The normalized `booking_services` junction table supports multiple services per booking and stores a captured service price. The booking detail pages can display the individual services associated with a booking. This demonstrates relational modeling beyond a single service field.

The newer wizard processor does not currently provide the required junction-table price value, so this feature needs runtime/schema alignment before it can be described as fully reliable.

### Payment-Proof Review Workflow

Customers submit image evidence of an initial payment, and administrators can inspect, approve, reject, and annotate the proof. Payment data records the method, amount, verification state, reviewer, remarks, and timestamp. This is technically meaningful because it models a human approval process rather than treating payment submission as automatically trusted.

### Role-Based Page Protection

Customer and administrator pages use shared helper functions to enforce session-based access. Customer-owned booking and notification queries also scope records to the authenticated customer ID. This demonstrates application-level authorization and ownership checks.

### Generic Administrator CRUD

The project uses an entity configuration file to define supported tables, primary keys, fields, labels, types, required values, and validation behavior. Shared management and form pages use that configuration to reduce duplicated CRUD page code for services, technicians, users, time slots, and watch types.

### Booking Status and Notification Coordination

Booking, payment, technician, completion, cancellation, and final-payment actions can create notification records tied to a booking. This gives customers an in-application history of important operational events.

### Customer Feedback Moderation and Technician Ratings

Completed bookings can produce one-to-five-star feedback, and the application updates technician rating data. Administrators can approve reviews before the public homepage displays them. This combines transactional feedback, moderation, and technician performance data.

### Client-Side Booking Experience

The project contains two different client-side booking experiences: a custom calendar-based form and a five-step wizard with a progress indicator, dynamic totals, payment instructions, and availability refresh. The wizard is a notable user-experience improvement documented by the project history.

## 12. Project Challenges

Personal development challenges cannot be reliably determined from source code alone. The developer should provide the actual challenges experienced during planning, implementation, testing, and deployment.

The following technical maintenance risks are evident from the current repository, but they should not be presented as confirmed personal development challenges without developer confirmation:

- Maintaining two booking implementations with different behavior.
- Reconciling the `watch_repair_shop` and `repair_shop` database names.
- Reconciling `Approved` and `Verified` payment verification values.
- Reconciling 20% and 50% down-payment labels and calculations across historical and current pages.
- Aligning the `payment_status` column used by PHP with the selected database schema.
- Correcting the wizard's `booking_services` insertion to match the required schema column.
- Managing old and new watch-type migrations.
- Preventing concurrent overbooking when multiple customers submit at the same time.
- Removing or protecting publicly accessible diagnostic and test scripts.
- Standardizing validation and state-changing request protection.

## 13. Portfolio-Friendly Project Descriptions

### Short Description

MC Repair is a PHP/MySQL watch-repair booking and management system that lets customers schedule services, submit payment proof, track repair progress, and provide feedback. Administrators manage bookings, payments, technicians, schedules, services, and customer reviews through a dedicated dashboard.

### Medium Description

MC Repair is a server-rendered PHP/MySQL web application designed to organize watch-repair appointments and shop operations. Customers can register, select watch types and repair services, choose appointment slots, upload payment proof, monitor booking status, receive in-application notifications, and rate completed services. Administrators can review payments, approve or reject bookings, assign technicians, update repair status, manage services and schedules, maintain user and technician records, and moderate public feedback. The system uses custom HTML/CSS/JavaScript interfaces, PHP sessions, MySQL relationships, local upload storage, and an internal availability endpoint.

### Full Case Study Description

MC Repair is a web-based watch-repair booking and management system built for a repair-shop workflow. It provides a public service website, a customer portal, and an administrator dashboard. The system is intended to replace disconnected manual handling of service requests, appointment scheduling, payment-proof review, technician assignment, repair progress, and customer feedback with a centralized application.

Customers can create accounts, manage their profile, select a watch type, choose one or more repair services, describe a problem, provide a service address, select a date and time slot, choose a payment method, and upload payment proof. They can then view their booking history, payment breakdown, assigned technician, status timeline, notifications, and final service outcome. Completed bookings can receive a one-to-five-star rating and written feedback.

Administrators use a protected dashboard to monitor booking and payment metrics, review individual bookings, verify or reject payment proof, assign technicians, update booking status, record remaining-payment state, manage service and scheduling data, maintain user and technician records, and moderate feedback before it appears on the public homepage. Technicians are represented as operational records rather than authenticated application users.

Technically, the project uses procedural/server-rendered PHP, MySQL through `mysqli`, PHP sessions, prepared statements, custom CSS, and vanilla JavaScript. Scheduling includes a PHP JSON availability endpoint that calculates open spots from available technicians and existing bookings. The database models customers, services, watch types, technicians, time slots, bookings, selected services, payments, feedback, and notifications. The repository also contains historical revisions and multiple schema versions, so the current implementation should be presented as an educational prototype or existing system with production-readiness limitations unless the developer confirms that the outstanding inconsistencies have been resolved.

## 14. Portfolio Feature List

### Core Features

- Customer registration and authentication.
- Customer profile and password management.
- Watch-repair service catalog with pricing and duration.
- Watch-type selection.
- Multiple-service booking support.
- Appointment date and time-slot selection.
- Technician-based appointment capacity display.
- Payment-method selection and payment-proof submission.
- Administrator payment verification and rejection workflow.
- Booking approval, cancellation, completion, and technician assignment.
- Customer booking history and detailed status tracking.
- Public booking lookup.
- Database-backed customer notifications.
- Completed-service ratings and written feedback.
- Administrator feedback moderation.
- Service, technician, user, watch-type, and time-slot management.

### Technical Features

- PHP session-based authentication and authorization.
- Separate customer and administrator access checks.
- MySQL relational model with foreign keys.
- Prepared SQL statements in most application queries.
- Password hashing and verification.
- Custom generic CRUD configuration.
- AJAX/fetch availability endpoint returning JSON.
- Multi-service junction-table modeling.
- File upload size and extension validation.
- Responsive custom CSS layout.
- Customer and administrator dashboards with database metrics.
- Workflow status badges and visual timelines.
- Modal-based payment review interactions.
- Database notification helper for booking events.
- Apache configuration for directory and response protections.

## 15. Recommended Portfolio Screenshots

### Screenshot 1: Public Homepage

**Page/Screen:** `index.php`

**What should be visible:** The hero section, service cards, approved review cards, booking call-to-action, and overall visual branding.

**Why it is important:** Demonstrates the public-facing design, business purpose, service catalog, and first impression of the application.

### Screenshot 2: Customer Dashboard

**Page/Screen:** `user/dashboard.php`

**What should be visible:** Summary cards, quick actions, recent bookings, notification count, and service cards using sanitized demo data.

**Why it is important:** Demonstrates the customer portal and database-driven dashboard experience.

### Screenshot 3: Five-Step Booking Wizard

**Page/Screen:** `user/booking_wizard.php`

**What should be visible:** Progress indicator, watch-type selection, service selection, or date/time step with availability information.

**Why it is important:** Demonstrates the application's most distinctive customer interaction and its guided booking flow.

### Screenshot 4: Booking Summary and Payment Step

**Page/Screen:** Final step of `user/booking_wizard.php`

**What should be visible:** Selected services, total cost, down-payment calculation, remaining balance, payment method selector, and upload control using safe test values.

**Why it is important:** Demonstrates pricing logic, payment workflow, and confirmation before submission.

### Screenshot 5: Customer Booking History

**Page/Screen:** `user/my_bookings.php`

**What should be visible:** Booking cards, status badges, status timeline, technician field, payment state, and action buttons with fake records.

**Why it is important:** Demonstrates post-submission tracking and customer transparency.

### Screenshot 6: Booking Detail and Progress

**Page/Screen:** `user/view_booking.php` or `track_order.php`

**What should be visible:** Service details, watch type, problem description, appointment, technician, status, payment summary, and timeline.

**Why it is important:** Demonstrates the complete customer-facing repair-progress experience.

### Screenshot 7: Administrator Dashboard

**Page/Screen:** `admin/dashboard.php`

**What should be visible:** Metrics cards, quick actions, sidebar navigation, and recent-bookings table with anonymized records.

**Why it is important:** Demonstrates operational reporting, role-specific navigation, and administrative overview.

### Screenshot 8: Payment Verification Workflow

**Page/Screen:** `admin/booking_detail.php` or `admin/edit_payment.php`

**What should be visible:** Payment amount, payment method, proof-review area using a fabricated or redacted image, verification actions, and remarks field.

**Why it is important:** Demonstrates a meaningful business workflow involving manual payment review and customer notification.

### Screenshot 9: Administrative CRUD Management

**Page/Screen:** `admin/manage.php?entity=services`, technicians, watch types, or time slots.

**What should be visible:** Entity table, active/inactive state, create/edit controls, and generic administration layout.

**Why it is important:** Demonstrates reusable CRUD management and maintenance of business configuration.

### Screenshot 10: Feedback Moderation

**Page/Screen:** `admin/view_feedback.php` or `admin/edit_feedback.php`

**What should be visible:** Rating, comment, technician association, approval state, and moderation action.

**Why it is important:** Demonstrates the feedback lifecycle from customer submission to public approval.

## 16. Sensitive Information Warning

Do not publish screenshots containing the following:

- Customer names, email addresses, phone numbers, addresses, or account details.
- Technician personal contact details or private email addresses.
- Payment-proof screenshots that contain names, account numbers, transaction IDs, QR codes, timestamps, or balances.
- Payment-account names, mobile numbers, bank names, bank account numbers, or payment email addresses.
- Administrator usernames, passwords, login hints, or demo credentials.
- Database host, database name, usernames, passwords, connection strings, or SQL import details.
- Session identifiers, access tokens, API keys, or browser developer-console output.
- Booking IDs, payment IDs, user IDs, or other identifiers if they can be linked to real records.
- Error pages, stack traces, Apache log output, or diagnostic pages.
- Screens from `view_errors.php`, `check_user.php`, `fix_user_issue.php`, migration checks, booking tests, or availability debugging pages.
- Real customer feedback that identifies a person or contains private service information.

Use fabricated data or blur/redact all private information before capturing screenshots. The login page and project documentation contain credential-like demonstration information; avoid showing those sections publicly.

## 17. Source-Verified References

The following files were used as primary evidence during analysis:

- `README.md`
- `PROJECT_SUMMARY.md`
- `FEATURES.md`
- `config/config.php`
- `config/database.php`
- `config/payment_accounts.php`
- `.htaccess`
- `index.php`
- `login.php`
- `user/signup.php`
- `user/dashboard.php`
- `user/booking.php`
- `user/booking_wizard.php`
- `user/process_booking_wizard.php`
- `user/my_bookings.php`
- `user/view_booking.php`
- `user/profile.php`
- `user/notifications.php`
- `user/add_feedback.php`
- `track_order.php`
- `api/get_timeslot_availability.php`
- `admin/dashboard.php`
- `admin/view_booking.php`
- `admin/booking_detail.php`
- `admin/edit_booking.php`
- `admin/view_payment.php`
- `admin/edit_payment.php`
- `admin/manage.php`
- `admin/form.php`
- `admin/config/entities.php`
- `admin/view_feedback.php`
- `admin/edit_feedback.php`
- `admin/technician_history.php`
- `assets/css/style.css`
- `assets/js/logout-confirm.js`
- `database/schema.sql`
- `database/COMPLETE_DATABASE.sql`
- `database/migrate_booking_improvements.sql`
- `database/add_watch_type.sql`
- `database/add_payment_status.sql`

## 18. Portfolio Project Data

PROJECT NAME:

MC Repair - Watch Repair Booking and Management System

PROJECT TYPE:

Server-rendered PHP/MySQL web application for watch-repair booking and shop administration.

PROJECT STATUS:

Existing educational or academic-style prototype with substantial implemented functionality. Historical documentation calls it complete, but current production readiness is not verified because the repository contains unresolved schema, workflow, and security inconsistencies.

YEAR/VERSION:

Historical documentation identifies version 2.0 revised in October 2025, with later enhancement notes. The authoritative current version and project year are not determinable from the current project files.

SHORT DESCRIPTION:

MC Repair is a PHP/MySQL watch-repair booking and management system where customers schedule services, submit payment proof, track repair progress, and provide feedback. Administrators manage bookings, payments, technicians, services, schedules, users, and reviews through a protected dashboard.

FULL DESCRIPTION:

MC Repair provides a public website, customer portal, and administrator dashboard for organizing watch-repair operations. Customers can register, select watch types and services, describe repair problems, schedule an appointment, provide a service address, select a payment method, upload payment proof, view booking progress, receive database-backed notifications, and rate completed services.

Administrators can review booking and payment information, verify or reject payment proof, assign technicians, update booking status, track remaining payment state, manage services, technicians, users, time slots, and watch types, and moderate feedback before it appears publicly. Technicians are represented as operational records and do not have a separate login portal.

The implementation uses procedural/server-rendered PHP, MySQL through `mysqli`, PHP sessions, custom CSS, vanilla JavaScript, local payment-proof storage, and an internal JSON availability endpoint. The database models bookings, selected services, payments, technicians, scheduling, feedback, and notifications. Multiple historical implementations and schema versions remain in the repository, so final portfolio wording should be updated if the developer later standardizes the active workflow and database.

PURPOSE:

Centralize watch-repair service requests, appointment scheduling, payment-proof review, technician assignment, repair-status tracking, notifications, and customer feedback.

PROBLEM ADDRESSED:

Reduces reliance on disconnected manual processes for managing repair appointments, customer records, payment verification, technician assignment, booking progress, and service reviews.

TARGET USERS:

Public visitors, customers, and shop administrators. Technicians are represented as administrator-managed records rather than authenticated users.

MY ROLE:

Mark for developer input. The current project files do not reliably identify the individual developer's role or exact contributions.

TECHNOLOGIES:

PHP, MySQL, `mysqli`, HTML5, CSS3, vanilla JavaScript, PHP sessions, Apache, XAMPP, JSON, AJAX/fetch, local filesystem uploads, and Apache `.htaccess` configuration.

USER ROLES:

Public visitor, customer, administrator, and technician as an operational record without a separate login portal.

CORE MODULES:

Public website, authentication and accounts, customer dashboard, booking and scheduling, payment-proof verification, booking administration, technician management, service and watch-type management, user management, time-slot management, feedback moderation, notifications, and public booking tracking.

CORE FEATURES:

Customer registration and login; profile and password management; watch-repair service selection; multi-service booking; watch-type selection; date and time-slot scheduling; technician-based slot-capacity display; payment-proof upload; administrator payment verification; booking approval/rejection/completion/cancellation; technician assignment; booking history and tracking; notifications; feedback and ratings; public order lookup; and administrator CRUD management.

TECHNICAL FEATURES:

Session-based role protection; password hashing and verification; prepared SQL statements in most queries; MySQL foreign-key relationships; generic configuration-driven CRUD; JSON availability endpoint; AJAX/fetch updates; local file uploads with size and extension checks; responsive custom CSS; dashboard metrics; status timelines; modal interactions; and database-backed notifications.

IMPORTANT WORKFLOWS:

Customer registration -> login -> booking creation -> payment-proof submission -> administrator verification -> booking approval or rejection -> technician assignment -> service completion -> final payment state -> customer feedback. Public tracking and in-application notifications provide additional status visibility.

DATABASE:

MySQL-compatible relational database accessed through PHP `mysqli`. Defined entities include administrators, customers, services, watch types, technicians, time slots, bookings, booking-service junction records, payments, feedback, and notifications. Foreign keys and cascading/set-null relationships are defined. The repository contains conflicting database names and schema versions; live database state was not inspected.

AUTHENTICATION:

Separate administrator and customer account tables with PHP sessions. Customers log in by email, administrators by username or email. Passwords use `password_hash()` and `password_verify()`. Customer and administrator page guards are implemented through shared helper functions.

SECURITY:

Application-level authentication and authorization, user-scoped booking queries, prepared statements in most queries, output escaping, password hashing, upload size and extension checks, Apache directory-index protection, HTTP-only session-cookie configuration, strict session mode, and selected response headers are present. No CSRF implementation was found, and public diagnostic scripts, GET-based state changes, direct public uploads, visible error reporting, and other production-security limitations remain evident from static inspection.

SUPABASE FEATURES:

None found. The project uses PHP sessions, MySQL, and local filesystem uploads instead.

UI/UX HIGHLIGHTS:

Custom dark navy interface with indigo/purple gradients, responsive cards and grids, customer dashboards, administrator sidebar navigation, status badges, booking timelines, a five-step booking wizard, custom calendar, dynamic availability display, payment modals, image preview modal, logout confirmation modal, interactive star rating, and responsive mobile layouts.

TECHNICAL HIGHLIGHTS:

Technician-based time-slot capacity calculation; multi-service relational booking model; manual payment-proof review workflow; session-based customer/administrator access control; configuration-driven administrator CRUD; database-backed notification workflow; feedback moderation and technician ratings; and dynamic client-side booking availability.

CHALLENGES:

Mark for developer input. Personal development challenges cannot be determined from source code alone. Source-evident technical risks include legacy/new booking-flow coexistence, schema conflicts, inconsistent payment terminology and percentages, wizard junction-table compatibility, migration inconsistencies, overbooking concurrency, and publicly accessible diagnostic files.

SOLUTIONS:

Mark for developer input. The repository shows implementation attempts such as a booking wizard, availability endpoint, shared CRUD configuration, and notification helper, but it does not reliably document the developer's decisions or final solutions to the identified risks.

WHAT I LEARNED:

Mark for developer input. Personal learning outcomes cannot be reliably inferred from source code alone.

RECOMMENDED PORTFOLIO SCREENSHOTS:

Homepage; customer dashboard; five-step booking wizard; booking summary/payment step; customer booking history; booking detail or public tracking page; administrator dashboard; payment verification workflow; service/technician/time-slot management; and feedback moderation. Use fabricated data and redact all private information.

SENSITIVE INFORMATION TO HIDE:

Customer and technician personal information; payment proofs and payment-account details; passwords and login hints; database credentials and connection details; session identifiers and tokens; API keys; booking/payment/user identifiers where sensitive; error logs; debug/test pages; and private feedback or administrative records.
